import sys
import types

# --- mock Kodi modula da import default.py ne pukne ---
xbmc = types.SimpleNamespace(LOGERROR=4, LOGINFO=1, log=lambda *a, **k: None)
xbmcgui = types.SimpleNamespace(
    Dialog=type("Dialog", (), {"notification": lambda *a, **k: None}),
    NOTIFICATION_ERROR=0,
    ListItem=lambda *a, **k: None,
)
xbmcplugin = types.SimpleNamespace(
    setResolvedUrl=lambda *a, **k: None,
    setPluginCategory=lambda *a, **k: None,
    setContent=lambda *a, **k: None,
    addDirectoryItem=lambda *a, **k: None,
    endOfDirectory=lambda *a, **k: None,
)

sys.modules["xbmc"] = xbmc
sys.modules["xbmcgui"] = xbmcgui
sys.modules["xbmcplugin"] = xbmcplugin
# ------------------------------------------------------

from default import extract_m3u8, http_get, PLAYER_URL

html = http_get(PLAYER_URL)

# (preporuka) snimi HTML da vidiš šta je server vratio
with open("page.html", "w", encoding="utf-8") as f:
    f.write(html)

print(extract_m3u8(html))
